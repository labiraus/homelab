{{ define "commonapi.configmap" }}

{{- end -}}